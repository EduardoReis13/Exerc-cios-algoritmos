#include<stdio.h>
#include<conio.h>

 void main()
 {
    int *ptr, **pont;
    int var;

    printf("Digite uma variavel:\n");
    scanf("%d", &var);

    ptr=&var;

    pont=&ptr;

    printf("%d\n", **pont);
    getch();





 }

#include<stdio.h>
#include<conio.h>

void main()
{
    int *ptr_1;
    int *ptr_2;
    int x,y;
    float  resultadoSub=0;



    printf("Digite ponteiro 1:\n ");
    scanf("%d", &x);

    printf("Digite ponteiro 2:\n ");
    scanf("\n%d", &y);

    ptr_1=&x;
    ptr_2=&y;


    if(*ptr_1 > *ptr_2)
    {

        printf("o maior eh o PRIMEIRO\n");
        printf("o resultado da subtracao do PRIMEIRO pelo SEGUNDO:%d\n", *ptr_1-*ptr_2);
    }

    if(*ptr_1 < *ptr_2){

        printf("O maior eh o SEGUNDO\n");
        printf("O resultado da subtracao do SEGUNDO pelo PRIMEIRO:%d\n", *ptr_2- *ptr_1);


    } else
      printf("Os dois numeros sao iguais\n");

    getch();
}

